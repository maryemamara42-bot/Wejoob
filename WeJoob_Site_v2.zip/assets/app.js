(function(){
'use strict';
/* ===== Réglages ===== */
// Réception des formulaires par e-mail via FormSubmit (compatible GitHub Pages).
// Après activation, remplacer l'adresse par l'alias aléatoire fourni par FormSubmit pour ne plus exposer l'e-mail.
var ENDPOINT='https://formsubmit.co/ajax/maryemamara42@gmail.com';
var NATIVE='https://formsubmit.co/maryemamara42@gmail.com';

var $=function(i){return document.getElementById(i)};
function esc(s){var d=document.createElement('div');d.textContent=s==null?'':s;return d.innerHTML}
var eur0=new Intl.NumberFormat('fr-FR',{style:'currency',currency:'EUR',maximumFractionDigits:0});
var eur2=new Intl.NumberFormat('fr-FR',{style:'currency',currency:'EUR'});
function num(id){var v=parseFloat($(id).value);return isNaN(v)||v<0?0:v}

/* ===== Menu mobile ===== */
var hd=document.querySelector('header.top'),bg=$('burger');
if(bg){
  bg.addEventListener('click',function(){var o=hd.classList.toggle('open');bg.setAttribute('aria-expanded',o)});
  document.querySelectorAll('nav.main a').forEach(function(a){a.addEventListener('click',function(){hd.classList.remove('open');bg.setAttribute('aria-expanded','false')})});
}

/* ===== Apparition douce (désactivée si mouvement réduit) ===== */
if('IntersectionObserver' in window&&!window.matchMedia('(prefers-reduced-motion: reduce)').matches){
  var rv=new IntersectionObserver(function(en){en.forEach(function(x){if(x.isIntersecting){x.target.classList.add('in');rv.unobserve(x.target)}})},{threshold:.1});
  document.querySelectorAll('section .card,section .steps li,section h2,details').forEach(function(el){el.classList.add('rv');rv.observe(el)});
}

/* ===== Outils ===== */
if($('tools')){
  var tabs=document.querySelectorAll('#tools [role=tab]');
  tabs.forEach(function(t){t.addEventListener('click',function(){
    tabs.forEach(function(x){var on=x===t;x.setAttribute('aria-selected',on);$(x.getAttribute('aria-controls')).hidden=!on});
  })});
  function rate(sel,cus){var v=$(sel).value;if(v==='custom'){var c=parseFloat($(cus).value);return isNaN(c)||c<0?null:Math.min(c,60)/100}return parseFloat(v)}
  function pct(r){return (r*100).toLocaleString('fr-FR',{maximumFractionDigits:1})+' %'}
  document.querySelectorAll('#tools .rate').forEach(function(s){
    var w=$(s.getAttribute('data-custom'));
    s.addEventListener('change',function(){w.hidden=s.value!=='custom'});
  });
  function calcA(){
    var r=rate('a-t','a-c'),h=num('a-h'),net=num('a-net'),f=num('a-f'),box=$('a-res');
    if(r===null||!h||!net){box.className='res';box.innerHTML='';return}
    var ca=(net+f)/(1-r);
    box.className='res on';
    box.innerHTML='<div class="big">'+eur0.format(Math.ceil(ca/h))+' de l’heure</div><p>Pour atteindre <strong>'+eur0.format(net)+'</strong> par mois, il faudrait facturer environ <strong>'+eur0.format(Math.round(ca))+'</strong>, dont environ <strong>'+eur0.format(Math.round(ca*r))+'</strong> de cotisations ('+pct(r)+') et <strong>'+eur0.format(f)+'</strong> de frais.</p>';
  }
  function calcB(){
    var r=rate('b-t','b-c'),ca=num('b-ca'),f=num('b-f'),box=$('b-res');
    if(r===null||!ca){box.className='res';box.innerHTML='';return}
    box.className='res on';
    box.innerHTML='<div class="big">'+eur0.format(Math.round(ca-ca*r-f))+' estimés pour vous</div><p>Sur <strong>'+eur0.format(ca)+'</strong> encaissés : environ <strong>'+eur0.format(Math.round(ca*r))+'</strong> de cotisations ('+pct(r)+') et <strong>'+eur0.format(f)+'</strong> de frais.</p>';
  }
  ['a-net','a-h','a-f','a-t','a-c'].forEach(function(i){$(i).addEventListener('input',calcA)});
  ['b-ca','b-f','b-t','b-c'].forEach(function(i){$(i).addEventListener('input',calcB)});
  calcA();calcB();

  // Devis / facture
  $('d-go').addEventListener('click',function(){
    var fact=$('d-type').value==='f',h=num('d-h'),p=num('d-p'),fr=num('d-fr'),tot=h*p+fr,d=new Date(),
        no=(fact?'F-':'D-')+d.getFullYear()+String(d.getMonth()+1).padStart(2,'0')+String(d.getDate()).padStart(2,'0'),
        rows='<tr><td>'+esc($('d-desc').value||'Prestation')+'</td><td class="r">'+h.toLocaleString('fr-FR')+' h</td><td class="r">'+eur2.format(p)+'</td><td class="r">'+eur2.format(h*p)+'</td></tr>';
    if(fr)rows+='<tr><td>Déplacement ou matériel</td><td class="r">1</td><td class="r">'+eur2.format(fr)+'</td><td class="r">'+eur2.format(fr)+'</td></tr>';
    var out=$('devis-out');out.className='on';
    out.innerHTML='<h3 style="font-size:24px">'+(fact?'Facture':'Devis')+' n° '+no+'</h3><p>Date : '+d.toLocaleDateString('fr-FR')+'</p>'
      +'<p><strong>'+esc($('d-me').value||'Prestataire')+'</strong>'+($('d-siret').value?'<br>SIRET : '+esc($('d-siret').value):'')+($('d-tel').value?'<br>Tél. : '+esc($('d-tel').value):'')+'</p>'
      +'<p><strong>Client :</strong> '+esc($('d-cl').value||'—')+($('d-adr').value?'<br>Adresse de la mission : '+esc($('d-adr').value):'')+'</p>'
      +'<table class="tbl"><thead><tr><th>Prestation</th><th class="r">Quantité</th><th class="r">Prix unitaire</th><th class="r">Total</th></tr></thead><tbody>'+rows+'</tbody></table>'
      +'<p style="font-size:19px"><strong>Total à payer : '+eur2.format(tot)+'</strong></p>'
      +($('d-tva').checked?'<p>TVA non applicable, art. 293 B du CGI.</p>':'')
      +(fact?'<p>À régler à réception. Mode de paiement : ………………</p>':'<p>Devis valable '+(num('d-v')||30)+' jours.</p><p>Bon pour accord, date et signature du client :</p><p style="height:56px"></p>');
    $('d-print').hidden=false;
  });

  // Suivi de missions (stockage local sur l'appareil)
  var KEY='wj-carnet',rows=[];
  try{rows=JSON.parse(localStorage.getItem(KEY)||'[]')}catch(e){rows=[]}
  function saveRows(){try{localStorage.setItem(KEY,JSON.stringify(rows))}catch(e){}}
  function drawRows(){
    var tb=$('c-body'),ca=0,fr=0;tb.innerHTML='';
    rows.forEach(function(r,i){
      ca+=r.m;fr+=r.f;
      var tr=document.createElement('tr'),dt=r.d?new Date(r.d+'T00:00:00').toLocaleDateString('fr-FR'):'—';
      tr.innerHTML='<td>'+esc(dt)+'</td><td>'+esc(r.c||'—')+'</td><td class="r">'+eur2.format(r.m)+'</td><td class="r">'+eur2.format(r.f)+'</td><td><button type="button" class="lnk" data-i="'+i+'" aria-label="Supprimer cette ligne">✕</button></td>';
      tb.appendChild(tr);
    });
    var box=$('c-sum');
    if(!rows.length){box.className='res';box.innerHTML='';return}
    box.className='res on';
    box.innerHTML='<div class="big">'+eur2.format(ca-fr)+' après frais</div><p>'+rows.length+' mission(s) · '+eur2.format(ca)+' encaissés · '+eur2.format(fr)+' de frais. Les cotisations ne sont pas déduites ici.</p>';
  }
  $('c-d').valueAsDate=new Date();
  $('c-add').addEventListener('click',function(){
    var m=num('c-m');if(!m){$('c-m').focus();return}
    rows.push({d:$('c-d').value,c:$('c-c').value,m:m,f:num('c-f')});
    saveRows();drawRows();$('c-c').value='';$('c-m').value='';$('c-f').value='';
  });
  $('c-body').addEventListener('click',function(e){
    var i=e.target.getAttribute&&e.target.getAttribute('data-i');
    if(i!==null&&i!==undefined){rows.splice(+i,1);saveRows();drawRows()}
  });
  $('c-clear').addEventListener('click',function(){if(rows.length&&confirm('Effacer toutes les missions de ce carnet ?')){rows=[];saveRows();drawRows()}});
  $('c-csv').addEventListener('click',function(){
    if(!rows.length)return;
    var csv='\ufeffDate;Client;Montant encaissé;Frais\n'+rows.map(function(r){return [r.d,'"'+(r.c||'').replace(/"/g,'""')+'"',r.m,r.f].join(';')}).join('\n');
    var a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));a.download='mes-missions.csv';document.body.appendChild(a);a.click();a.remove();
  });
  drawRows();
}

/* ===== Investisseur : montant ===== */
if($('inv-range')){
  var rg=$('inv-range'),dc=$('inv-disc');
  var upM=function(){
    var v=+rg.value,t=dc.checked?'À discuter':(v>=500000?'500 000 € et plus':eur0.format(v));
    $('inv-out').textContent=t;$('inv-montant').value=t;rg.disabled=dc.checked;
  };
  rg.addEventListener('input',upM);dc.addEventListener('change',upM);
  rg.form.addEventListener('reset',function(){setTimeout(upM,0)});
  upM();
}

/* ===== Formulaires : validation accessible + envoi réel par e-mail ===== */
function wireForm(form){
  var btn=form.querySelector('[type=submit]'),msg=form.querySelector('.msg');
  form.setAttribute('novalidate','');
  function clear(){
    form.querySelectorAll('.err').forEach(function(e){e.remove()});
    form.querySelectorAll('[aria-invalid]').forEach(function(e){e.removeAttribute('aria-invalid');e.removeAttribute('aria-describedby')});
    msg.className='msg';msg.textContent='';
  }
  function showErr(el,text,anchor){
    var p=document.createElement('p');p.className='err full';p.textContent=text;p.id='err'+Math.random().toString(36).slice(2,8);
    (anchor||el).insertAdjacentElement('afterend',p);
    el.setAttribute('aria-invalid','true');el.setAttribute('aria-describedby',p.id);
  }
  function validate(){
    var n=0,first=null,seen={};
    function bad(el,t,a){showErr(el,t,a);n++;if(!first)first=el}
    form.querySelectorAll('[required]').forEach(function(el){
      if(el.type==='checkbox'){if(!el.checked)bad(el,'Merci de cocher cette case pour continuer.',el.closest('label'))}
      else if(el.type==='radio'){
        if(seen[el.name])return;seen[el.name]=1;
        if(!form.querySelector('input[name="'+el.name+'"]:checked'))bad(el,'Merci de faire un choix.',el.closest('fieldset'));
      }
      else if(el.type==='file'){
        var f=el.files[0];
        if(!f)bad(el,'Ajoutez votre CV (PDF ou Word).');
        else if(!/\.(pdf|docx?)$/i.test(f.name))bad(el,'Le CV doit être au format PDF ou Word.');
        else if(f.size>5*1024*1024)bad(el,'Le fichier dépasse 5 Mo. Envoyez un fichier plus léger.');
      }
      else if(!el.value.trim())bad(el,'Ce champ est obligatoire.');
    });
    form.querySelectorAll('input[type=email]').forEach(function(el){
      if(el.value.trim()&&!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(el.value.trim())&&!el.hasAttribute('aria-invalid'))bad(el,'Cette adresse e-mail ne semble pas valide.');
    });
    if(form.hasAttribute('data-need-contact')){
      var em=form.elements.email,tel=form.elements.telephone;
      if(em&&tel&&!em.value.trim()&&!tel.value.trim())bad(em,'Indiquez au moins un e-mail ou un téléphone pour que nous puissions vous répondre.');
    }
    return {n:n,first:first};
  }
  function nativeSend(){
    var k={a:form.getAttribute('action'),m:form.getAttribute('method'),t:form.getAttribute('target'),e:form.getAttribute('enctype')},tmp=[];
    form.setAttribute('action',NATIVE);form.setAttribute('method','POST');form.setAttribute('target','_blank');
    if(form.querySelector('input[type=file]'))form.setAttribute('enctype','multipart/form-data');
    [['_subject',form.getAttribute('data-subject')],['_template','table']].forEach(function(kv){var i=document.createElement('input');i.type='hidden';i.name=kv[0];i.value=kv[1];form.appendChild(i);tmp.push(i)});
    HTMLFormElement.prototype.submit.call(form);
    setTimeout(function(){
      tmp.forEach(function(i){i.remove()});
      ['action','method','target','enctype'].forEach(function(a,x){var v=[k.a,k.m,k.t,k.e][x];v===null?form.removeAttribute(a):form.setAttribute(a,v)});
      msg.className='msg ok';msg.textContent='Une nouvelle page s’est ouverte pour finaliser l’envoi. Vérifiez qu’elle affiche une confirmation avant de fermer.';
    },400);
  }
  form.addEventListener('submit',function(e){
    e.preventDefault();clear();
    var hp=form.querySelector('[name=_honey]');if(hp&&hp.value)return;
    var v=validate();
    if(v.n){msg.className='msg bad';msg.textContent='Merci de corriger '+(v.n>1?'les '+v.n+' champs signalés':'le champ signalé')+' avant d’envoyer.';v.first.focus();return}
    var label=btn.textContent,hasFile=!!form.querySelector('input[type=file]'),init;
    btn.disabled=true;btn.textContent='Envoi en cours…';
    if(hasFile){
      var fd=new FormData(form);fd.append('_subject',form.getAttribute('data-subject'));fd.append('_template','table');fd.append('_captcha','false');
      init={method:'POST',headers:{'Accept':'application/json'},body:fd};
    }else{
      var o={};new FormData(form).forEach(function(val,key){if(typeof val==='string')o[key]=o[key]?o[key]+', '+val:val});
      o._subject=form.getAttribute('data-subject');o._template='table';o._captcha='false';
      init={method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify(o)};
    }
    fetch(ENDPOINT,init).then(function(r){return r.json()}).then(function(j){
      if(!j||(j.success!=='true'&&j.success!==true))throw new Error(j&&j.message?j.message:'réponse inattendue du service d’envoi');
      form.reset();msg.className='msg ok';msg.textContent=form.getAttribute('data-success');
    }).catch(function(err){
      msg.className='msg bad';
      var why=location.protocol==='file:'?'La page est ouverte depuis un fichier : l’envoi ne fonctionne qu’une fois le site en ligne.':'Motif : '+esc(err&&err.message?err.message:'connexion impossible')+'.';
      msg.innerHTML='Votre message n’a pas été envoyé. '+why+' Vous pouvez réessayer, ou utiliser l’envoi alternatif.<br><button type="button" class="btn ghost sm" id="alt-send">Envoyer d’une autre façon</button>';
      $('alt-send').addEventListener('click',nativeSend);
    }).then(function(){btn.disabled=false;btn.textContent=label});
  });
}
document.querySelectorAll('form.sub[data-subject]').forEach(wireForm);
})();
